import Tkinter as tk
import cv2
from PIL import Image,ImageTk
import os
import numpy
import pytesseract
import ttk

LARGE_FONT=["Verdana",12]

class noPlateRecg(tk.Tk):

    def __init__(self,*args,**kwargs):

        tk.Tk.__init__(self,*args,**kwargs)
        tk.Tk.wm_title(self,"Number Plate Recg Soft")   

        self.dir = args[0]
        
        container = tk.Frame (self)
        container.pack(side="top",fill="both",expand=True)
        container.rowconfigure(0,weight=1)
        container.columnconfigure(0,weight=1)

        self.frames={}

    
        for F in (StartPage,noPlatePage):

            frame = F(container,self)

            self.frames[F]=frame

            frame.grid(row=0,column=0,sticky="nsew")


        self.show_frame(StartPage)


    def show_frame(self,Page) :
#container here is the argument passed page we want to open
        frame= self.frames[Page]
        frame.tkraise()






class StartPage(tk.Frame):

    def __init__(self,parent,controller):

        tk.Frame.__init__(self,parent)

        heading=tk.Label(self,text="Welcome to the number Plate Recoginzation software",font=LARGE_FONT)
        heading.pack(pady=10,padx=10)

        go_ahead_button=ttk.Button(self, text="Go ahead",
                                  command=lambda: controller.show_frame(noPlatePage))
        go_ahead_button.pack()

        exit_button=ttk.Button(self, text="Exit",
                              command=controller.destroy)
        exit_button.pack()



class noPlatePage(tk.Frame):
    
    
    def __init__(self,parent,controller):
        self.counter = 1
        self.string = "None"
        tk.Frame.__init__(self,parent)

        heading=ttk.Label(self,text="Number plate recognization system",font=LARGE_FONT)
        heading.grid(row=0,column=1,pady=10,padx=10)
        self.number=ttk.Label(self,text=self.string,font=("Halvetica",10),relief='sunken')
        self.number.grid(row=3,column=1,columnspan=3,sticky='nsew')
        

        img=ImageTk.PhotoImage(Image.open("download.jpg"))
        self.image=tk.Label(self, image=img)
        self.image.image=img
        self.image.grid(row=1,column=1)
        
        
        

        stpg_button=ttk.Button(self, text="StartPage",
                                  command=lambda: controller.show_frame(StartPage))
        stpg_button.grid(row=2,column=4)


        next_button=ttk.Button(self, text="Next",
                               command=lambda: self.openImage(controller.dir))
        next_button.grid(row=2,column=2)


        back_button=ttk.Button(self, text="Back",
                               command=lambda:self.backPress(controller.dir))
        back_button.grid(row=2,column=0)

    def openImage(self,Dir):
        k=1
        for i in os.listdir(Dir):
            if i.endswith('jpg') and k==self.counter:
                img2=Image.open("%s\%s"%(Dir,i))
                img2=img2.resize((img2.size[0]/2,img2.size[1]/2))
                img2=ImageTk.PhotoImage(img2)
                self.image.configure(image=img2)
                self.image.image=img2
                self.ImageToText(Dir,i)
                break
            else:
                k=k+1 
        self.counter=self.counter+1
        
       

    def backPress(self, Dir):
        self.counter=self.counter-2
        if self.counter==0:
            self.counter=1
        self.openImage(Dir)
        
        
    def ImageToText(self,Dir,File):
        orig= cv2.imread('%s\%s'%(Dir,File))
        h,w=orig.shape[0],orig.shape[1]
        image=orig.copy()
        image=cv2.resize(image,(w/2,h/2))
        gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
        gray=cv2.bilateralFilter(gray,11,35,35)
        #ret,temp=cv2.threshold(gray,255,200,cv2.THRESH_BINARY)
        #cv2.imshow('gray',gray)
        edged=cv2.Canny(gray,50,150)
        #cv2.imshow('edged',edged)
        cnts, hierarchy = cv2.findContours(edged.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        cnts = sorted(cnts, key = cv2.contourArea, reverse = True)[:10] # get largest five contour area
        screenCnt = None
        for c in cnts:
            peri=cv2.arcLength(c, True)
            approx= cv2.approxPolyDP(c, 0.02*peri, True)
            print len(approx)
            if len(approx)==4:
                screenCnt = approx
                break
        cv2.drawContours(image,[screenCnt], -1, (0, 255, 0), 3)
        x,y,width,height=cv2.boundingRect(screenCnt)
        roi=image[(y+(height/20)):y+height-(height/20),(x+(width/20)):x+width-(width/20)]
        
        roi_gray=cv2.cvtColor(roi,cv2.COLOR_BGR2GRAY)
        th=cv2.adaptiveThreshold(roi_gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,145,1)
        #cv2.imshow('roi_gray',roi_thresh)
        #cv2.imshow("The contour",image)

        #print th.shape
        cv2.imshow("th",th)
        self.string= pytesseract.image_to_string(th)
        self.number.configure(text=self.string)
        self.number.text=self.string
        print self.string
        cv2.waitKey(0)
        cv2.destroyAllWindows()

             





noPlate= noPlateRecg('no_plate_templates')

noPlate.mainloop()






