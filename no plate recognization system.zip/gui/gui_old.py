from Tkinter import *
import cv2
from PIL import Image,ImageTk
import pytesseract
import numpy
import os
Dir,key='no_plate_templates',0

img=cv2.imread("download.jpg")
imgDisp=Image.open("download.jpg")
def backPress():
    global key
    if key !=1:
        key= key-2
        openImage()
    elif key==1:
        key=key-1
        openImage()


def openImage():
    global Dir,key,img,imgDisp
    key+=1
    i=1
    for f in os.listdir(Dir):
        print key,i
        if i==key:
            img=cv2.imread("%s\%s"%(Dir,f))
            imgDisp=Image.open("%s\%s"%(Dir,f))
            displayImage()
            break
        else:
            i=i+1
    

def displayImage():
    pass
    


root=Tk()
#Image variable
imgDisp=ImageTk.PhotoImage(Image.open("download.jpg"))

TopFrame=Frame(root)
TopFrame.pack(side=TOP,fill='x')

#imagelabel
imgDisp=ImageTk.PhotoImage(imgDisp)
imlabel=Label(TopFrame,image=imgDisp)
imlabel.pack(side=LEFT)

#defining frame
BottomFrame=Frame(root)
BottomFrame.pack(fill='x')


#buttons
BackButton=Button(BottomFrame,text='Back',bd=4,command=backPress)
NextButton=Button(BottomFrame,text='Next',bd=4,command=openImage)
BackButton.grid(row=0,columnspan=2)
NextButton.grid(row=0,column=3,columnspan=2)

#displaying image for the first time
#displayImage()




root.mainloop()

    
       
        
        
