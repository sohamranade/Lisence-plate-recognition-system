import cv2
import numpy as np

ix,iy,fx,fy,switch=-1,-1,-1,-1,'lol'
# mouse callback function
def draw(event,x,y,flags,param):
    global ix,iy,fx,fy,switch
    if event==cv2.EVENT_LBUTTONDOWN:
        ix,iy=x,y
    elif event ==cv2.EVENT_LBUTTONUP:
        fx,fy=x,y
        switch=raw_input('is it correct ?\n>>')    
        if switch =='yes':
            cv2.rectangle(img,(ix, iy),(fx, fy),(0,255,255),2)
            



img = cv2.imread('mario.png',1)
original=cv2.imread('mario.png',1)
gray=cv2.cvtColor(original,cv2.COLOR_BGR2GRAY)
cv2.namedWindow('image')

cv2.setMouseCallback('image',draw)

while(1):
    cv2.imshow('image',img)
    if switch == 'yes':
        print "we will we will rock you"
        roi=gray[iy:fy,ix:fx]
        w,h=fx-ix,fy-iy
        print w,h
        cv2.destroyWindow('image')
        cv2.imshow('roi',roi)
        res=cv2.matchTemplate(gray,roi,cv2.TM_CCOEFF_NORMED)
        threshold = 0.7
        loc = np.where( res >= threshold)
        for pt in zip(*loc[::-1]):
            cv2.rectangle(original, pt, (pt[0] + w, pt[1] + h), (255,255,255), 2)
        cv2.imshow('Detected',original)
        cv2.waitKey(0)
        
        break
    k = cv2.waitKey(1) & 0xFF
    if k == 27:
        break
cv2.destroyAllWindows()
