import imutils
from PIL import Image
import pytesseract
import numpy as np
import cv2
orig= cv2.imread('image.jpg')
h,w=orig.shape[0],orig.shape[1]
image=orig.copy()
image=cv2.resize(image,(600,600))
gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
gray=cv2.bilateralFilter(gray,15,35,35)
#ret,temp=cv2.threshold(gray,255,200,cv2.THRESH_BINARY)
cv2.imshow('gray',gray)
edged=cv2.Canny(gray,50,150)
cv2.imshow('edged',edged)
cv2.waitKey(0)
cnts, hierarchy = cv2.findContours(edged.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
cnts = sorted(cnts, key = cv2.contourArea, reverse = True)[:10] # get largest five contour area
screenCnt = None
for c in cnts:
    peri=cv2.arcLength(c, True)
    approx= cv2.approxPolyDP(c, 0.02*peri, True)
    print len(approx)
    if len(approx)==4:
        screenCnt = approx
        break
print screenCnt
cv2.drawContours(image,[screenCnt], -1, (0, 255, 0), 3)
x,y,width,height=cv2.boundingRect(temp)
roi=image[y:y+height,x:x+width]
roi_gray=cv2.cvtColor(roi,cv2.COLOR_BGR2GRAY)
#ret,roi_thresh=cv2.threshold(roi_gray,100,255,cv2.THRESH_BINARY)
th=cv2.adaptiveThreshold(roi_gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,145,1)
#cv2.imshow('roi_gray',roi_thresh)
cv2.imshow("Game Boy Screen",image)
print th.shape
cv2.imshow("th",th)
string= pytesseract.image_to_string(th)
print string
cv2.waitKey(0)
cv2.destroyAllWindows()



