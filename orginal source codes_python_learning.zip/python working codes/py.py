from sys import exit
from random import randint
import time


def Athena():
    print"You are in Athena's lair."   
    print"You desperately keep looking for Anabeth"
    print"Instead you find a note."
    print"You run towards it. As you are about to pick. You hear a noise.\nYou turn to find a Monster standing in front of you.\n You take out riptide"
    print"What will you do?"
    print"stab him or take the note and run for life"
    while True:
        x=raw_input()
        if x=='stab':
            print"You try to fight him. You try with all your might.\nHe is too strong for you.\nHe over powers you and...."
            ret= 'Death'
            break 
        elif x=='run':
            print"You decide to run."
            print"You take the note and run with a your might."
            print"He is following you but as you move across the old bridge the monster trips and gets trapped."
            print"You cut the bridge and see the monster die fue to falling."
            print"You go to the other side."
            print"You cut the bridge and see the monster die fue to falling."
            print"""You open the note.It is written by annabeth. It says "Follow me to the place where the clouds are scared to go..."  """
            print"You understand it has to be the Zeus Palace. You head there...."
            ret = 'Zeus Palace'
            break
        else:
            print"stab or run !!!!"
    return ret       

def Zeus():
    print "-----------\n"
    print "You tavel to Zeus's Palace on Blackjack....."
    print "you want to head in so you go towards the door...You know that your relationship with Zeus has not been good hence you are on guard and alert"
    print "As you go near the door you hear some sweaking noise"
    print "You keep walking....."
    print "The sweaking is more elaborate..."
    print "Suddenly !!! you get trapped into a cage....One which zeus has for the clouds... "
    print "You try to remember the passcode to free yourself.."
    print """On the walls you see something.."""""
    print """I am Zeus... I am also called _______ and ________ in roman and norse mythology...."""
    print"you try thinking abt the names."
    print"you come up with 2 names.Remember you have only 2 chances"

    i=0
    while i < 3 :
        x,y=raw_input('1.'),raw_input('2.')
        if x== 'Jupiter' and y=='Thor':
            break
        else:
            print"you hear a clicking sound but the cage doesnt open"
            print"%d chances left"%(2-i)
            i+=1
    if i==3:
        print "you couldn't judge the password...."
        return 'Death'
    else:
        print "You manage to open the door.."
        print "you walk inside and find another note there....."
        print """ its written "Thief!!!!" """
        print "You know its hermis's cove..."
        print "YOu call blackjack to ride there..."
        return 'Hermis cove'


def Hermis():
    print "sdsad"

def Exit():
    exit()

def Death():
    print "LOL !!!! dont worry everyone dies one day.."
    print "You died a bit early... "
    print "Try again !!"
    return 'Exit'
    

def Introduction():
    print  "You are the one and only Percy jackson, The son of posideon."
    print  "You find yourself in a tough spot as annabeth has vanished."
    print  "You realise that a possible spot for her is the Athena's Lair Hence you go looking for her there"
    print  "Do you really wanna go looking?"
    print "yes or no"
    while True:
        x=raw_input()
        if x=='yes':
           print "Travelling"
           ret= 'Athena lair'
           break
       
        elif x=='no':
            print"you wait and wait and wait....\nuntil...."
            ret= 'Death'
            break
        else:
            print"yes or no !!!!"
    
    return ret






map={  'Athena lair': Athena,
       'Zeus Palace': Zeus,
       'Hermis cove': Hermis,
       'Introduction':Introduction,
       'Death':Death,
       'Exit':Exit
       }




def Open(current):
   for i in map.keys():
       if current==i:
            value=map[i]()
            break
   return value

current='Introduction'

while True:
    current=Open(current)
    

   
        

