# Number-Plate-Recognition-System
Computer Vision Project(EC353).

### Built Using:
* Python 2.7
* OpenCV 3.0.0
* Tesseract 
### Screenshot
![Screenshot](/testData/SS1.png)

